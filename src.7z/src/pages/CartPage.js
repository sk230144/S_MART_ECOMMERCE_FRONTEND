import React from 'react'
import Carta from '../features/cart/Carta.js'

const CartPage = () => {
  return (
    <div>
      <Carta></Carta>
    </div>
  )
}

export default CartPage
