import React from 'react'
import Login from '../features/auth/components/Login.js'

const LoginPage = () => {
  return (
    <div>
      <Login></Login>
    </div>
  )
}

export default LoginPage
