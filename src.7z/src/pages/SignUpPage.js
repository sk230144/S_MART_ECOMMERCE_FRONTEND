import React from 'react'
import SignUp from '../features/auth/components/SignUp.js'

const SignUpPage = () => {
  return (
    <div>
      <SignUp></SignUp>
    </div>
  )
}

export default SignUpPage
